/* DopCar ENCOR — Service Worker
   Offline-first app shell. Ao publicar nova versão do app, ALTERE a constante
   CACHE abaixo (ex.: bump da versão) para forçar a atualização nos dispositivos. */
const CACHE = 'dopcar-encor-v11.10.2';

const ASSETS = [
  './',
  './index.html',
  './manifest.json',
  './vendor/html2canvas.min.js',
  './vendor/jspdf.umd.min.js',
  './icon-192.png',
  './icon-512.png',
  './icon-512-maskable.png'
];

// Instala: pré-cacheia o app shell
self.addEventListener('install', (e) => {
  e.waitUntil(
    caches.open(CACHE)
      .then((c) => c.addAll(ASSETS))
      .then(() => self.skipWaiting())
  );
});

// Ativa: remove caches antigos
self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

// Fetch: cache-first; rede como fallback; navegação offline cai no index.html
self.addEventListener('fetch', (e) => {
  const req = e.request;
  if (req.method !== 'GET') return;

  e.respondWith(
    caches.match(req).then((hit) => {
      if (hit) return hit;
      return fetch(req).then((res) => {
        // guarda cópia de GETs same-origin bem-sucedidos (cache progressivo)
        try {
          if (res && res.ok && new URL(req.url).origin === self.location.origin) {
            const copy = res.clone();
            caches.open(CACHE).then((c) => c.put(req, copy));
          }
        } catch (_) {}
        return res;
      }).catch(() => {
        // offline: para navegações, serve o app shell
        if (req.mode === 'navigate') return caches.match('./index.html');
        return caches.match(req);
      });
    })
  );
});

// Permite atualização imediata quando a página pedir
self.addEventListener('message', (e) => {
  if (e.data === 'SKIP_WAITING') self.skipWaiting();
});
